"""
URL configuration for django_pjt project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path('make_data/',views.make_data),
    path('',views.RealEstateListCreateView.as_view()),
    path('get_regions/',views.get_regions),
    path('recent/<str:region>/', views.get_recent_real_estate, name='get_real_estate'),
    path('link/', views.link_real_estate_to_user, name='link_real_estate_to_user'),
    path('<int:real_estate_id>/unlink_user/', views.unlink_real_estate_from_user, name='unlink_real_estate_from_user'),
]


