# from django.db import models
# from django.conf import settings

# class Deposit(models.Model):
#     dcls_month = models.DateField()
#     fin_co_no = models.CharField(max_length=100) 
#     kor_co_nm = models.CharField(max_length=100)
#     fin_prdt_cd = models.CharField(max_length=100)
#     fin_prdt_nm = models.CharField(max_length=100)
#     join_way = models.CharField(max_length=100)
#     mtrt_int = models.TextField(blank=True, null=True)
#     spcl_cnd = models.TextField(blank=True, null=True)
#     join_deny = models.IntegerField(blank=True, null=True)
#     join_member = models.TextField(blank=True, null=True)
#     etc_note = models.TextField(blank=True, null=True)
#     max_limit = models.IntegerField(blank=True, null=True)
#     dcls_strt_day = models.CharField(max_length=100)
#     dcls_end_day = models.CharField(max_length=100)
#     fin_co_subm_day = models.CharField(max_length=100)
#     @property
#     def contract_users(self):
#         return self.users.count()

# class DepositOptions(models.Model):
#     deposit = models.ForeignKey(Deposit, related_name='options', on_delete=models.CASCADE)
#     intr_rate_type = models.CharField(max_length=1)
#     intr_rate_type_nm = models.CharField(max_length=2)
#     save_trm = models.CharField(max_length=3)
#     intr_rate = models.FloatField(null=True)
#     intr_rate2 = models.FloatField(null=True)

# class Saving(models.Model):
#     dcls_month = models.DateField()
#     fin_co_no = models.CharField(max_length=100) 
#     kor_co_nm = models.CharField(max_length=100)
#     fin_prdt_cd = models.CharField(max_length=100)
#     fin_prdt_nm = models.CharField(max_length=100)
#     join_way = models.CharField(max_length=100)
#     mtrt_int = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
#     mtrt_int = models.TextField(blank=True, null=True)
#     spcl_cnd = models.TextField(blank=True, null=True)
#     join_deny = models.IntegerField(blank=True, null=True)
#     join_member = models.TextField(blank=True, null=True)
#     etc_note = models.TextField(blank=True, null=True)
#     max_limit = models.IntegerField(blank=True, null=True)
#     dcls_strt_day = models.CharField(max_length=100)
#     dcls_end_day = models.CharField(max_length=100)
#     fin_co_subm_day = models.CharField(max_length=100)
#     @property
#     def contract_users(self):
#         return self.users.count()

# class SavingOptions(models.Model):
#     saving = models.ForeignKey(Saving, related_name='options', on_delete=models.CASCADE)
#     intr_rate_type = models.CharField(max_length=1)
#     intr_rate_type_nm = models.CharField(max_length=2)
#     rsrv_type = models.CharField(max_length=1)
#     rsrv_type_nm = models.CharField(max_length=5) 
#     save_trm = models.CharField(max_length=3)
#     intr_rate = models.FloatField(null=True)
#     intr_rate2 = models.FloatField(null=True)


from django.db import models
from django.conf import settings

class Deposit(models.Model):
    dcls_month = models.DateField()
    fin_co_no = models.CharField(max_length=100)
    kor_co_nm = models.CharField(max_length=100)
    fin_prdt_cd = models.CharField(max_length=100)
    fin_prdt_nm = models.CharField(max_length=100)
    join_way = models.CharField(max_length=100)
    mtrt_int = models.TextField(blank=True, null=True)
    spcl_cnd = models.TextField(blank=True, null=True)
    join_deny = models.IntegerField(blank=True, null=True)
    join_member = models.TextField(blank=True, null=True)
    etc_note = models.TextField(blank=True, null=True)
    max_limit = models.IntegerField(blank=True, null=True)
    dcls_strt_day = models.CharField(max_length=100)
    dcls_end_day = models.CharField(max_length=100, blank=True, null=True)  # 추가된 필드
    fin_co_subm_day = models.CharField(max_length=100)

    @property
    def contract_users(self):
        return self.users.count()

class DepositOptions(models.Model):
    deposit = models.ForeignKey(Deposit, related_name='options', on_delete=models.CASCADE)
    intr_rate_type = models.CharField(max_length=1)
    intr_rate_type_nm = models.CharField(max_length=2)
    save_trm = models.CharField(max_length=3)
    intr_rate = models.FloatField(null=True)
    intr_rate2 = models.FloatField(null=True)

class Saving(models.Model):
    dcls_month = models.DateField()
    fin_co_no = models.CharField(max_length=100)
    kor_co_nm = models.CharField(max_length=100)
    fin_prdt_cd = models.CharField(max_length=100)
    fin_prdt_nm = models.CharField(max_length=100)
    join_way = models.CharField(max_length=100)
    mtrt_int = models.TextField(blank=True, null=True)
    spcl_cnd = models.TextField(blank=True, null=True)
    join_deny = models.IntegerField(blank=True, null=True)
    join_member = models.TextField(blank=True, null=True)
    etc_note = models.TextField(blank=True, null=True)
    max_limit = models.IntegerField(blank=True, null=True)
    dcls_strt_day = models.CharField(max_length=100)
    dcls_end_day = models.CharField(max_length=100, blank=True, null=True)  # 추가된 필드
    fin_co_subm_day = models.CharField(max_length=100)

    @property
    def contract_users(self):
        return self.users.count()

class SavingOptions(models.Model):
    saving = models.ForeignKey(Saving, related_name='options', on_delete=models.CASCADE)
    intr_rate_type = models.CharField(max_length=1)
    intr_rate_type_nm = models.CharField(max_length=2)
    rsrv_type = models.CharField(max_length=1)  # 추가된 필드
    rsrv_type_nm = models.CharField(max_length=5)  # 추가된 필드
    save_trm = models.CharField(max_length=3)
    intr_rate = models.FloatField(null=True)
    intr_rate2 = models.FloatField(null=True)
